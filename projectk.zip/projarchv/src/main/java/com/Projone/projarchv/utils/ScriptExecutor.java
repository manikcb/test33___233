package com.Projone.projarchv.utils;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class ScriptExecutor {

    public String executeScript(String nodeId, String method) {
        String scriptPath = "/home/manibandla/.ssh/node_manager.sh";
        StringBuilder output = new StringBuilder();

        try {
            ProcessBuilder processBuilder = new ProcessBuilder("bash", scriptPath, nodeId, method);
            processBuilder.directory(new java.io.File("/home/manibandla"));

            Process process = processBuilder.start();

            BufferedReader outputReader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            BufferedReader errorReader = new BufferedReader(new InputStreamReader(process.getErrorStream()));

            String line;
            while ((line = outputReader.readLine()) != null) {
                output.append(line).append("\n");
            }

            while ((line = errorReader.readLine()) != null) {
                output.append("ERROR: ").append(line).append("\n");
            }

            int exitCode = process.waitFor();
            output.append("Script executed with exit code: ").append(exitCode);

        } catch (Exception e) {
            output.append("An error occurred: ").append(e.getMessage());
        }

        return output.toString();
    }
}
