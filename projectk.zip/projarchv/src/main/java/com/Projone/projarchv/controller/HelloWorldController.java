package com.Projone.projarchv.controller;
import java.util.List;
import java.util.ArrayList;
import com.Projone.projarchv.utils.ScriptExecutor;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;
@Controller
public class HelloWorldController {

    private final ScriptExecutor scriptExecutor;

    public HelloWorldController() {
        this.scriptExecutor = new ScriptExecutor();
    }
     @GetMapping("/") // Serve the HTML form when accessing the root URL
    public String showForm() {
        return "index"; // This maps to src/main/resources/templates/index.html
    }


    @PostMapping("/hostmanage")
    public String manageHosts(@RequestBody RequestPayload payload) {
        StringBuilder result = new StringBuilder();
List<String> nodes = new ArrayList<>(); 

        for (String nodeId : payload.getNodes()) {
            result.append("Node: ").append(nodeId).append("\n");
            String scriptResult = scriptExecutor.executeScript(nodeId, payload.getMethod());
            result.append(scriptResult).append("\n\n");
result.append("Node: ").append(nodeId).append("\n");
        }

        return result.toString();
    }

     @PostMapping("/test")
     @ResponseBody
    public String receiveArray(@RequestBody List<String> data) {
        // Log or process the received data
        System.out.println("Received data: " + data);

        // Return a confirmation message
        return "Data received successfully: " + data;
    }
    // Payload class to handle JSON input
    static class RequestPayload {
        private List<String> nodes;
        private String method;

        public List<String> getNodes() {
            return nodes;
        }

        public void setNodes(List<String> nodes) {
            this.nodes = nodes;
        }

        public String getMethod() {
            return method;
        }

        public void setMethod(String method) {
            this.method = method;
        }
    }
}
